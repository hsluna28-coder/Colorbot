@echo off
cd /d %~dp0
cd uvhid
uvhid.exe install uvhid.inf